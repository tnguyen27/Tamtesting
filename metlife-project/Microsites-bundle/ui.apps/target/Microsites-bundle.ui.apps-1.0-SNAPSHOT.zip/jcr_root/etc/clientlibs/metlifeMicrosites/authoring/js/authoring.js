MetlifeMicrosites = {
    Components: {},
    Forms: {},
    Global: {}
};